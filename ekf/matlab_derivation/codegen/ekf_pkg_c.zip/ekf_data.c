/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: ekf_data.c
 *
 * MATLAB Coder version            : 5.4
 * C/C++ source code generated on  : 02-Nov-2022 22:58:20
 */

/* Include Files */
#include "ekf_data.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
boolean_T isInitialized_ekf = false;

/*
 * File trailer for ekf_data.c
 *
 * [EOF]
 */
