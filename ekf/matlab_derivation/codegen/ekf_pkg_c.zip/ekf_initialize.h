/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: ekf_initialize.h
 *
 * MATLAB Coder version            : 5.4
 * C/C++ source code generated on  : 02-Nov-2022 22:58:20
 */

#ifndef EKF_INITIALIZE_H
#define EKF_INITIALIZE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void ekf_initialize(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for ekf_initialize.h
 *
 * [EOF]
 */
