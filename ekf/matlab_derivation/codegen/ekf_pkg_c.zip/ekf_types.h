/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: ekf_types.h
 *
 * MATLAB Coder version            : 5.4
 * C/C++ source code generated on  : 02-Nov-2022 22:58:20
 */

#ifndef EKF_TYPES_H
#define EKF_TYPES_H

/* Include Files */
#include "rtwtypes.h"

#endif
/*
 * File trailer for ekf_types.h
 *
 * [EOF]
 */
